<!-- Header section start -->
<?php include 'include/header.php'; ?>

    <!--====== PAGE TITLE PART START ======-->

    <div class="page-title-area bg_cover" style="background-image: url(assets/images/page-title-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title-content">
                        <h3 class="title">Daily Updates</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Daily Updates</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--====== PAGE TITLE PART ENDS ======-->

    <!--====== UPPCOMING EVENTS PART START ======-->
    
    <section class="upcoming-events-area events-page">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="upcoming-events-item">
                        <div class="item mt-20">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="upcoming-events-content d-block d-md-flex align-items-center">
                                        <div class="thumb">
                                            <img src="assets/images/events-1.jpg" alt="">
                                            <div class="date">
                                                <span>07 <br> Feb</span>
                                            </div>
                                        </div>
                                        <div class="content ml-65">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i> 12:00 am </li>
                                                <li><i class="fa fa-user-o"></i> Admin </li>
                                            </ul>
                                            <h4 class="title">The new startup is on the way</h4>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered in some form humour.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <!-- <div class="events-btn text-left text-lg-right">
                                        <a class="main-btn main-btn-2" href="#">Join event</a>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="item mt-20">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="upcoming-events-content d-block d-md-flex align-items-center">
                                        <div class="thumb">
                                            <img src="assets/images/events-2.jpg" alt="">
                                            <div class="date">
                                                <span>07 <br> Feb</span>
                                            </div>
                                        </div>
                                        <div class="content ml-65">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i> 12:00 am </li>
                                                <li><i class="fa fa-user-o"></i> Admin </li>
                                            </ul>
                                            <h4 class="title">The new startup is on the way</h4>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered in some form humour.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <!-- <div class="events-btn text-left text-lg-right">
                                        <a class="main-btn main-btn-2" href="#">Join event</a>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="item mt-20">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="upcoming-events-content d-block d-md-flex align-items-center">
                                        <div class="thumb">
                                            <img src="assets/images/events-3.jpg" alt="">
                                            <div class="date">
                                                <span>07 <br> Feb</span>
                                            </div>
                                        </div>
                                        <div class="content ml-65">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i> 12:00 am </li>
                                                <li><i class="fa fa-user-o"></i> Admin </li>
                                            </ul>
                                            <h4 class="title">The new startup is on the way</h4>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered in some form humour.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <!-- <div class="events-btn text-left text-lg-right">
                                        <a class="main-btn main-btn-2" href="#">Join event</a>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                        <div class="item mt-20">
                            <div class="row align-items-center">
                                <div class="col-lg-9">
                                    <div class="upcoming-events-content d-block d-md-flex align-items-center">
                                        <div class="thumb">
                                            <img src="assets/images/events-4.jpg" alt="">
                                            <div class="date">
                                                <span>07 <br> Feb</span>
                                            </div>
                                        </div>
                                        <div class="content ml-65">
                                            <ul>
                                                <li><i class="fa fa-clock-o"></i> 12:00 am </li>
                                                <li><i class="fa fa-user-o"></i> Admin </li>
                                            </ul>
                                            <h4 class="title">The new startup is on the way</h4>
                                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered in some form humour.</p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-3">
                                    <!-- <div class="events-btn text-left text-lg-right">
                                        <a class="main-btn main-btn-2" href="#">Join event</a>
                                    </div> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== UPPCOMING EVENTS PART ENDS ======-->

    <!--====== WE LISTEN PART START ======-->
    
    <section class="we-listen-area events-listen-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="we-listen-content">
                        <h3 class="title">We listen and work together.</h3>
                        <p>There are many variations of passages the majority have suffered alteration in some fo injected humour.</p>
                        <div class="row">
                            <div class="col-lg-6">
                                <div class="thumb mt-30">
                                    <img src="assets/images/listed-item-1.jpg" alt="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="thumb mt-30">
                                    <img src="assets/images/listed-item-2.jpg" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="faq-accordion">
                        <div class="accrodion-grp"  data-grp-name="faq-accrodion">
                            <div class="accrodion active  animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms">
                                <div class="accrodion-inner">
                                    <div class="accrodion-title">
                                        <h4>1. Reserve conference rooms</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div><!-- /.accrodion-inner -->
                            </div>
                            <div class="accrodion   animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="300ms">
                                <div class="accrodion-inner">
                                    <div class="accrodion-title">
                                        <h4>2. Post or respond to job listings</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div><!-- /.accrodion-inner -->
                            </div>
                            <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="600ms">
                                <div class="accrodion-inner">
                                    <div class="accrodion-title">
                                        <h4>3. Flexibility of monthly terms</h4>
                                    </div>
                                    <div class="accrodion-content">
                                        <div class="inner">
                                            <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                        </div><!-- /.inner -->
                                    </div>
                                </div><!-- /.accrodion-inner -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== WE LISTEN PART ENDS ======-->

   
    
 
    <!-- Footer section start -->
    <?php include 'include/footer.php'; ?>