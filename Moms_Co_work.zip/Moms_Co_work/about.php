<!-- Header section start -->
<?php include 'include/header.php'; ?>

    <!--====== PAGE TITLE PART START ======-->

    <div class="page-title-area bg_cover" style="background-image: url(assets/images/page-title-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title-content">
                        <h3 class="title">About</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">About</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--====== PAGE TITLE PART ENDS ======-->

    <!--====== GET TO KNOW PART START ======-->
    
    <section class="get-to-know-area">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="get-to-know-thumb mr-70 animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="0ms">
                        <img src="assets/images/get-to-know-thumb.jpg" alt="">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="get-to-know-content">
                        <h3 class="title">Get to know about our Moms Co-Work company.</h3>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly.</p>
                        <ul>
                            <li><i class="fa fa-check"></i> High speed internet</li>
                            <li><i class="fa fa-check"></i> Uninterruptible power supply</li>
                            <li><i class="fa fa-check"></i> Fully Airconditioned rooms</li>
                            <li><i class="fa fa-check"></i> Office boy service</li>
                            <li><i class="fa fa-check"></i> Fully equipped kitchen</li>
                        </ul>
                        <a class="main-btn main-btn-2" href="book-a-tour.php">Book a tour</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="about-pattern">
            <img src="assets/images/shape-pattern.png" alt="">
        </div>
    </section>
    
    <!--====== GET TO KNOW PART ENDS ======-->

    <!--====== CODESK CHANGING PART START ======-->
    
    <section class="codesk-changing-area bg_cover" style="background-image: url(assets/images/codesk-changing-bg.jpg);">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <div class="codesk-changing-text">
                        <h3 class="title">Moms Co-Work is changing the way people and companies work.</h3>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="codesk-changing-play text-left text-lg-right">
                        <a class="main-btn video-popup" href="https://www.youtube.com/watch?v=_9MEYFNyilQ"><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== CODESK CHANGING PART ENDS ======-->

    <!--====== TESTIMONIAL PART START ======-->
    
    <div class="testimonial-title-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="testimonial-title text-center">
                        <h2 class="title">What they are saying.</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="testimonial-area">
        <div class="container">
            <div class="row testimonial-active">
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Jessica rose</h4>
                        <span>Freelancer</span>
                        <img src="assets/images/testimonial-1.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Kevin martin</h4>
                        <span>CEO</span>
                        <img src="assets/images/testimonial-2.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Sarah albert</h4>
                        <span>Developer</span>
                        <img src="assets/images/testimonial-3.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Kevin martin</h4>
                        <span>CEO</span>
                        <img src="assets/images/testimonial-2.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonial-pattern">
            <img src="assets/images/testimonial-pattern.png" alt="">
        </div>
    </section>
    
    <!--====== TESTIMONIAL PART ENDS ======-->

    <!--====== JOIN COMMUNITY PART START ======-->
    
    <section class="join-community-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="join-community-content">
                        <h3 class="title animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="0ms">Join a community of early stage startups.</h3>
                        <p class=" animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="300ms">Lorem ipsum is simply free text dolor sit amett adipiscing elit. When an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                        <a class="main-btn animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="600ms" href="about.php">Read more</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="join-community-counter">
            <div class="item">
                <h3 class="title counter">880</h3>
                <p>Creative people space is available.</p>
            </div>
            <div class="item item-2">
                <h3 class="title"><span class="counter">70</span>+</h3>
                <p>Conference & meeting rooms available.</p>
            </div>
        </div>
        <div class="community-logo">
            <img src="assets/images/community-logo.png" alt="">
        </div>
    </section>
    
    <!--====== JOIN COMMUNITY PART ENDS ======-->

    <!--====== TEAM PART START ======-->
    
    <section class="team-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="team-title text-center">
                        <h3 class="title">Team members</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-7 col-sm-8">
                    <div class="team-item mt-30 animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="0ms">
                        <div class="team-thumb">
                            <img src="assets/images/team-1.jpg" alt="team">
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Kevin martin</h4>
                            <span>Developer</span>
                            <ul>
                            <li><a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="https://twitter.com/i/flow/login"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-sm-8">
                    <div class="team-item mt-30 animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="100ms">
                        <div class="team-thumb">
                            <img src="assets/images/team-2.jpg" alt="team">
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Kevin martin</h4>
                            <span>Developer</span>
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7 col-sm-8">
                    <div class="team-item mt-30 animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="200ms">
                        <div class="team-thumb">
                            <img src="assets/images/team-3.jpg" alt="team">
                        </div>
                        <div class="team-content text-center">
                            <h4 class="title">Kevin martin</h4>
                            <span>Developer</span>
                            <ul>
                                <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="team-pattern">
            <img src="assets/images/services-dot.png" alt="">
        </div>
    </section>
    
    <!--====== TEAM PART ENDS ======-->

    <!--====== COMPANY LOGOS PART START ======-->
<!--     
    <section class="company-logos-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="company-logos-text">
                        <h3 class="title">Clients we <br> have worked <br> with.</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    
    <!--====== COMPANY LOGOS PART ENDS ======-->
    
<!-- Footer section start -->
<?php include 'include/footer.php'; ?>