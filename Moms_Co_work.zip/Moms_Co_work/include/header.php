<!doctype html>
<html lang="en">

<head>
   
    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <!--====== Title ======-->
    <title>Moms Co-Work</title>
    
    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/we-know-logo.png" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    
    <!--====== Fontawesome css ======-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    
    <!--====== flaticon css ======-->
    <link rel="stylesheet" href="assets/css/flaticon.css">
    
    <!--====== nice select css ======-->
    <link rel="stylesheet" href="assets/css/nice-select.css">
    
    <!--====== animate css ======-->
    <link rel="stylesheet" href="assets/css/animate.min.css">
    
    <!--====== Magnific Popup css ======-->
    <link rel="stylesheet" href="assets/css/magnific-popup.css">
    
    <!--====== Slick css ======-->
    <link rel="stylesheet" href="assets/css/slick.css">
    
    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">
    
    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">
  
  
</head>

<body>

    <!-- PRELOADER -->
    <div class="preloader">
        <div class="lds-ellipsis">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- END PRELOADER -->

    <!--====== OFFCANVAS MENU PART START ======-->

    <div class="off_canvars_overlay">
                
    </div>
    <div class="offcanvas_menu">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="offcanvas_menu_wrapper">
                        <div class="canvas_close">
                            <a href="javascript:void(0)"><i class="fa fa-times"></i></a>  
                        </div>
                        <div class="offcanvas-social">
                            <ul class="text-center">
                                <li><a href="%24.html"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="%24.html"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="%24.html"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="%24.html"><i class="fa fa-dribbble"></i></a></li>
                            </ul>
                        </div>
                        <div id="menu" class="text-left ">
                            <ul class="offcanvas_main_menu">
                                <li class="menu-item-has-children active">
                                    <a href="index.php">Home</a>
                                </li>
                                <li class="menu-item-has-children active">
                                    <a href="about.php">About</a>
                                </li>
                                <li class="menu-item-has-children active">
                                    <a href="daily_update.php">Daily Updates</a>
                                </li>
                                <li class="menu-item-has-children active">
                                    <a href="gallery.php">Gallery</a>
                                </li>
                                <!-- <li class="menu-item-has-children active">
                                    <a href="#">Blog</a>
                                </li> -->
                                <li class="menu-item-has-children active">
                                    <a href="contact.php">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <div class="offcanvas_footer">
                            <span><a href="mailto:richa.oneapps@gmail.com"><i class="fa fa-envelope-o" style="padding-right:2%;"></i>richa.oneapps@gmail.com</a></span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!--====== OFFCANVAS MENU PART ENDS ======-->
   
    <!--====== HEADER PART START ======-->
    
    <header class="header-area">
        <div class="header-top-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="header-top">
                            <ul>
                                <li><a href="richa.oneapps@gmail.com"><i class="flaticon-message"></i>richa.oneapps@gmail.com</a></li>
                                <li><a href="tel:+91 88843 32801"><i class="flaticon-phone-call"></i>+91 88843 32801</a></li>
                                <!-- <li><a href="#"><i class="flaticon-placeholder"></i>Hoysala nagar Horamavu 3rd Main, 6th Cross Rd, Bengaluru, Karnataka 560016</a></li> -->
                            </ul>
                            <!-- <div class="dropdown d-none d-md-block">
                                <img src="assets/images/map.png" alt="">
                                <select>
                                    <option value="1">English</option>
                                    <option value="2">Bangla</option>
                                    <option value="3">urdu</option>
                                    <option value="4">Hindi</option>
                                </select>
                            </div> -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="main-header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="main-header-item d-flex justify-content-between align-items-center">
                            <div class="main-header-menus  d-flex">
                                <div class="header-logo">
                                    <a href="index.php"><img src="assets/images/logo.png" alt="logo"></a>
                                </div>
                                <div class="header-menu d-none d-lg-block">
                                    <ul>
                                        <li>
                                            <a  href="index.php">Home</a>
                                           
                                        </li>
                                        <li>
                                            <a  href="about.php">About</a>
                                        </li>
                                        <li>
                                            <a href="daily_update.php">Daily Updates</a>
                                        
                                        </li>
                                        <li>
                                            <a href="gallery.php">Gallery</a>
                                     
                                        </li>
                                        <!-- <li>
                                            <a href="services.php">Services</a>
                                        </li> -->
                                        <li><a href="contact.php">Contact</a></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="header-social d-flex align-items-center">
                                <ul class="d-none d-lg-block">
                                <li><a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a></li>
                                <li><a href="https://twitter.com/i/flow/login"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                                <li><a href="https://www.youtube.com/"><i class="fa fa-youtube"></i></a></li>
                                </ul>
                                <div class="toggle-btn ml-30 canvas_open d-lg-none d-block">
                                    <i class="fa fa-bars"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </header>
    
    <!--====== HEADER PART ENDS ======-->