<!-- Header section start -->
<?php include 'include/header.php'; ?>

    <!--====== BANNER PART START ======-->
    <section class="banner-slide">
        <div class="banner-area bg_cover d-flex align-items-center" style="background-image: url(assets/images/banner-bg-1.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-slide-number">
                            <span>01</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7">
                        <div class="banner-content">
                            <span data-animation="fadeInDown" data-delay=".1s"><img src="assets/images/banner-icon.png" alt=""> Welcome to Moms Co-Work</span>
                            <h1 data-animation="fadeInLeft" data-delay=".5s" class="title">Comfortable coworking space.</h1>
                            <a data-animation="fadeInLeft" data-delay="1s" class="main-btn" href="book-a-tour.php">Book a tour</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner-social">
                <ul>
                            <li><a href="https://www.facebook.com/"><i class="fa fa-facebook-square"></i></a></li>
                            <li><a href="https://twitter.com/i/flow/login"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="https://www.instagram.com/"><i class="fa fa-instagram"></i></a></li>
                </ul>
            </div>
        </div>
        <div class="banner-area bg_cover d-flex align-items-center" style="background-image: url(assets/images/banner-bg-2.jpg);">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="banner-slide-number">
                            <span>02</span>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-7">
                        <div class="banner-content">
                            <span data-animation="fadeInDown" data-delay=".1s"><img src="assets/images/banner-icon.png" alt=""> Welcome to Moms Co-Work</span>
                            <h1 data-animation="fadeInLeft" data-delay=".5s" class="title">Comfortable coworking space.</h1>
                            <a data-animation="fadeInLeft" data-delay="1s" class="main-btn" href="book-a-tour.php">Book a tour</a>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner-social">
                <ul>
                    <li><a href="#">Twitter</a></li>
                    <li><a href="#">Facebook</a></li>
                    <li><a href="#">Linkedin</a></li>
                </ul>
            </div>
        </div>
    </section>
    
    <!--====== BANNER PART ENDS ======-->

    <!--====== BEST CREATIVE PART START ======-->
    
    <section class="best-creative-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="best-creative-bg">
                        <div class="row">
                            <div class="col-lg-7">
                                <div class="best-creative-content">
                                    <h3 class="title">Best creative working environments that suits your business.</h3>
                                    <p>Sed quia lipsum dolor sit atur adipiscing elit is nunc quis tellus sed ligula porta ultricies quis nec magna neulla. Lorem ipsum simply dolor sit amet, consectetur adipiscing elit.</p>
                                </div>
                            </div>
                            <div class="col-lg-5">
                                <div class="best-creative-list">
                                    <div class="best-creative-seats">
                                        <i class="flaticon-computer"></i>
                                        <h3 class="title counter">37400</h3>
                                        <p>Total seats are available</p>
                                        <span>480 sq ft coworking space</span>
                                    </div>
                                    <div class="best-creative-list-item">
                                        <ul>
                                            <li><i class="fa fa-check"></i>High speed internet</li>
                                            <li><i class="fa fa-check"></i>Uninterruptible power supply</li>
                                            <li><i class="fa fa-check"></i>Fully Airconditioned rooms</li>
                                            <li><i class="fa fa-check"></i>Office boy service</li>
                                            <li><i class="fa fa-check"></i>Fully equipped kitchen</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== BEST CREATIVE PART ENDS ======-->

    <!--====== SPACE TO MAKE PART START ======-->
    
    <section class="space-to-make-area pt-120 pb-120">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6">
                    <div class="space-to-make-thumb animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="0ms">
                        <img src="assets/images/space-to-make-thumb.jpg" alt="">
                        <div class="thumb-content">
                            <span>Over 50 <br> locations <br> worldwide</span>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-10">
                    <div class="space-to-make-content">
                        <h3 class="title">Space to make your greatest impact.</h3>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable.</p>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="space-to-make-item mt-30">
                                    <a href="#">
                                        <i class="flaticon-workspace"></i>
                                        <span>Flexible private offices</span>
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="space-to-make-item mt-30">
                                    <a href="#">
                                        <i class="flaticon-meeting"></i>
                                        <span>Fully custom spaces</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <p class="text">If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text.</p>
                        <a class="main-btn main-btn-2" href="book-a-tour.php">Book a tour</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-pattern">
            <img src="assets/images/shape-pattern.png" alt="">
        </div>
        <div class="shape-pattern-2">
            <img src="assets/images/we-know-line.png" alt="">
        </div>
    </section>
    
    <!--====== SPACE TO MAKE PART ENDS ======-->

    <!--====== TEUSTED PART START ======-->
    
    <div class="trusted-area bg_cover pt-120 pb-120" style="background-image: url(assets/images/trusted-bg.jpg);">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9">
                    <div class="trusted-item text-center">
                        <h3 class="title">Trusted & comfortable space for creative people.</h3>
                        <a class="main-btn" href="book-a-tour.php">Book a tour</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--====== TEUSTED PART ENDS ======-->

    <!--====== BENEFITS PART START ======-->
    
    <section class="benefits-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="benefits-thumb">
                        <img src="assets/images/benefits-thumb.jpg" alt="benefits">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="benefits-content">
                        <div class="benefits-title">
                            <h3 class="title">Benefits of our coworking spaces.</h3>
                        </div>
                        <div class="faq-accordion">
                            <div class="accrodion-grp"  data-grp-name="faq-accrodion">
                                <div class="accrodion active  animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms">
                                    <div class="accrodion-inner">
                                        <div class="accrodion-title">
                                            <h4>1. Reserve conference rooms</h4>
                                        </div>
                                        <div class="accrodion-content">
                                            <div class="inner">
                                                <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                            </div><!-- /.inner -->
                                        </div>
                                    </div><!-- /.accrodion-inner -->
                                </div>
                                <div class="accrodion   animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="300ms">
                                    <div class="accrodion-inner">
                                        <div class="accrodion-title">
                                            <h4>2. Post or respond to job listings</h4>
                                        </div>
                                        <div class="accrodion-content">
                                            <div class="inner">
                                                <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                            </div><!-- /.inner -->
                                        </div>
                                    </div><!-- /.accrodion-inner -->
                                </div>
                                <div class="accrodion  animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="600ms">
                                    <div class="accrodion-inner">
                                        <div class="accrodion-title">
                                            <h4>3. Flexibility of monthly terms</h4>
                                        </div>
                                        <div class="accrodion-content">
                                            <div class="inner">
                                                <p>There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.</p>
                                            </div><!-- /.inner -->
                                        </div>
                                    </div><!-- /.accrodion-inner -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="benefits-pattern">
            <img src="assets/images/benefits-pattern.png" alt="">
        </div>
        <div class="benefits-dot">
            <img src="assets/images/benefits-dot.png" alt="">
        </div>
    </section>
    
    <!--====== BENEFITS PART ENDS ======-->

    <!--====== SERVICES PART START ======-->
    
    <section class="services-area pt-90 pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-3">
                    <div class="services-title">
                        <h3 class="title">What we are offering to creative people.</h3>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-services mt-30">
                        <i class="flaticon-wifi"></i>
                        <a href="#"><h4 class="title">High speed internet</h4></a>
                        <p>There are many new variations of pasages of available text.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-services mt-30">
                        <i class="flaticon-tray"></i>
                        <a href="#"><h4 class="title">Fully equipped kitchen</h4></a>
                        <p>There are many new variations of pasages of available text.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-services mt-30">
                        <i class="flaticon-parking"></i>
                        <a href="#"><h4 class="title">Huge parking space</h4></a>
                        <p>There are many new variations of pasages of available text.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-services mt-30">
                        <i class="flaticon-room"></i>
                        <a href="#"><h4 class="title">Conference  rooms</h4></a>
                        <p>There are many new variations of pasages of available text.</p>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6 col-sm-6">
                    <div class="single-services mt-30">
                        <i class="flaticon-cctv"></i>
                        <a href="#"><h4 class="title">Full security cameras</h4></a>
                        <p>There are many new variations of pasages of available text.</p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="services-book mt-30">
                        <h3 class="title">Book a free day tour to experience our benefits</h3>
                        <a class="main-btn main-btn-2" href="book-a-tour.php">Book a tour</a>
                    </div>
                </div>
            </div>
        </div>
        <div class="services-pattern">
            <img src="assets/images/services-pattern.png" alt="pattern">
        </div>
        <div class="services-dot">
            <img src="assets/images/services-dot.png" alt="pattern">
        </div>
    </section>
    
    <!--====== SERVICES PART ENDS ======-->

    <!--====== GALLERY PART START ======-->
    
    <section class="gallery-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="gallery-title text-center">
                        <h3 class="title">Our photo gallery</h3>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid p-0">
            <div class="gallery-itmes">
                <div class="row no-gutters gallery-active">
                    <div class="col-lg-3">
                        <div class="gallery-thumb">
                            <img src="assets/images/gallery-1.jpg" alt="gallery">
                            <a class="main-btn image-popup" href="assets/images/gallery-1.jpg"><i class="flaticon-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="gallery-thumb">
                            <img src="assets/images/gallery-2.jpg" alt="gallery">
                            <a class="main-btn image-popup" href="assets/images/gallery-2.jpg"><i class="flaticon-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="gallery-thumb">
                            <img src="assets/images/gallery-3.jpg" alt="gallery">
                            <a class="main-btn image-popup" href="assets/images/gallery-3.jpg"><i class="flaticon-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="gallery-thumb">
                            <img src="assets/images/gallery-4.jpg" alt="gallery">
                            <a class="main-btn image-popup" href="assets/images/gallery-4.jpg"><i class="flaticon-plus"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3">
                        <div class="gallery-thumb">
                            <img src="assets/images/gallery-5.jpg" alt="gallery">
                            <a class="main-btn image-popup" href="assets/images/gallery-5.jpg"><i class="flaticon-plus"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== GALLERY PART ENDS ======-->

    <!--====== FUN FACTS PART START ======-->
    
    <div class="fun-facts-area pt-120 pb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-8">
                    <div class="fun-facts-item text-center animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="0ms">
                        <h3 class="title counter" >880</h3>
                        <span>Creative people space is available.</span>
                    </div>
                </div>
                <div class="col-lg-4 col-md-8">
                    <div class="fun-facts-item active text-center animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
                        <h3 class="title"><span class="counter">70</span>+</h3>
                        <span>Conference & meeting rooms available.</span>
                    </div>
                </div>
                <div class="col-lg-4 col-md-8">
                    <div class="fun-facts-item text-center animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="600ms">
                        <h3 class="title counter">440</h3>
                        <span>Seats are already busy with freelancers.</span>
                    </div>
                </div>
            </div>
        </div>
        <div class="fun-facts-pattern">
            <img src="assets/images/fun-facts-pattern.png" alt="">
        </div>
        <div class="fun-dots">
            <img src="assets/images/fun-dots.png" alt="dots">
        </div>
    </div>
    
    <!--====== FUN FACTS PART ENDS ======-->

    <!--====== WE KNOWS PART START ======-->
    
    <section class="we-knows-area pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="we-knows-content">
                        <h3 class="title">We known for having cool workspaces filled with amenities.</h3>
                        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of lorem Ipsum.</p>
                        <img src="assets/images/we-know-thumb.jpg" alt="thumb">
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="we-knows-center mt-10 animated wow fadeInRight" data-wow-duration="1500ms" data-wow-delay="0ms">
                        <div class="we-knows-item d-block d-sm-flex">
                            <div class="we-knows-item-content">
                                <h4 class="title">Explore our standard private offices</h4>
                                <a class="main-btn" href="#">More <i class="flaticon-right-arrow"></i></a>
                            </div>
                            <div class="we-knows-item-thumb">
                                <img src="assets/images/we-know-item-1.jpg" alt="">
                            </div>
                        </div>
                        <div class="we-knows-item item-2 d-block d-sm-flex mt-10">
                            <div class="we-knows-item-thumb">
                                <img src="assets/images/we-know-item-2.jpg" alt="">
                            </div>
                            <div class="we-knows-item-content">
                                <h4 class="title">Rent a conference & meeting rooms</h4>
                                <a class="main-btn" href="#">More <i class="flaticon-right-arrow"></i></a>
                            </div>
                        </div>
                        <div class="we-know-logo">
                            <img src="assets/images/we-know-logo.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="we-know-line">
            <img src="assets/images/we-know-line.png" alt="line">
        </div>
    </section>
    
    <!--====== WE KNOWS PART ENDS ======-->

    <!--====== CODESK CHANGING PART START ======-->
    
    <section class="codesk-changing-area bg_cover" style="background-image: url(assets/images/codesk-changing-bg.jpg);">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-7">
                    <div class="codesk-changing-text">
                        <h3 class="title">Lorem ipsum dolor sit amet consectetur, adipisicing elit. Vel, eligendi?</h3>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div class="codesk-changing-play text-left text-lg-right">
                        <a class="main-btn video-popup" href="https://www.youtube.com/watch?v=_9MEYFNyilQ"><i class="fa fa-play"></i></a>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== CODESK CHANGING PART ENDS ======-->

    <!--====== TESTIMONIAL PART START ======-->
    
    <div class="testimonial-title-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="testimonial-title text-center">
                        <h2 class="title">What they are saying.</h2>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="testimonial-area">
        <div class="container">
            <div class="row testimonial-active">
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Jessica rose</h4>
                        <span>Freelancer</span>
                        <img src="assets/images/testimonial-1.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Kevin martin</h4>
                        <span>CEO</span>
                        <img src="assets/images/testimonial-2.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Sarah albert</h4>
                        <span>Developer</span>
                        <img src="assets/images/testimonial-3.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="testimonial-item text-center">
                        <p>I was impresed by the moling services, not lorem ipsum is simply free text of used by refreshing. Neque porro este qui dolorem ipsum quia.</p>
                        <h4 class="title">Kevin martin</h4>
                        <span>CEO</span>
                        <img src="assets/images/testimonial-2.jpg" alt="testimonial">
                        <div class="icon">
                            <img src="assets/images/quote-icon.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="testimonial-pattern">
            <img src="assets/images/testimonial-pattern.png" alt="">
        </div>
    </section>
    
    <!--====== TESTIMONIAL PART ENDS ======-->

    <!--====== CTA PART START ======-->
    
    <section class="cta-area animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="0ms">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="cta-bg">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="cta-text">
                                    <h3 class="title">Fully equipped meeting rooms for rent</h3>
                                    <a class="main-btn" href="book-a-tour.php">Book a tour</a>
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="cta-text">
                                    <p>Sed quia lipsum dolor sit atur adipiscing elit is nunc quis tellus sed ligula porta ultricies quis nec magna neulla. Lorem ipsum dolor sit amet, consectetur adipiscing elit.</p>
                                </div>
                            </div>
                        </div>
                        <div class="cta-dot">
                            <img src="assets/images/cta-dot.png" alt="cta">
                        </div>
                        <div class="cta-dot-2">
                            <img src="assets/images/cta-dot-2.png" alt="cta">
                        </div>
                        <div class="cta-dot-3">
                            <img src="assets/images/cta-dot-3.png" alt="cta">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== CTA PART ENDS ======-->


    <!--====== NEWS PART START ======-->
    
    <!-- <section class="news-area pb-150">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-5">
                    <div class="news-title text-center">
                        <h3 class="title">News & articles.</h3>
                    </div>
                </div>
            </div>
            <div class="row justify-content-center">
                <div class="col-lg-4 col-md-7">
                    <div class="mt-30">
                        <div class="news-item bg_cover" style="background-image: url(assets/images/news-item-bg.jpg);">
                            <div class="item">
                                <img src="assets/images/news-user-1.jpg" alt="">
                                <ul>
                                    <li><i class="fa fa-user-o"></i> by admin</li>
                                    <li><i class="fa fa-comments-o"></i> 2 comments</li>
                                </ul>
                            </div>
                            <h3 class="title">Why your business absolutely needs a virtual office</h3>
                            <a href="single-news.html"><i class="flaticon-right-arrow"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7">
                    <div class="mt-30">
                        <div class="news-item active bg_cover" style="background-image: url(assets/images/news-item-bg.jpg);">
                            <div class="item">
                                <img src="assets/images/news-user-2.jpg" alt="">
                                <ul>
                                    <li><i class="fa fa-user-o"></i> by admin</li>
                                    <li><i class="fa fa-comments-o"></i> 2 comments</li>
                                </ul>
                            </div>
                            <h3 class="title">Why your business absolutely needs a virtual office</h3>
                            <a href="single-news.html"><i class="flaticon-right-arrow"></i></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4 col-md-7">
                    <div class="mt-30">
                        <div class="news-item bg_cover" style="background-image: url(assets/images/news-item-bg.jpg);">
                            <div class="item">
                                <img src="assets/images/news-user-3.jpg" alt="">
                                <ul>
                                    <li><i class="fa fa-user-o"></i> by admin</li>
                                    <li><i class="fa fa-comments-o"></i> 2 comments</li>
                                </ul>
                            </div>
                            <h3 class="title">Why your business absolutely needs a virtual office</h3>
                            <a href="single-news.html"><i class="flaticon-right-arrow"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="shape-pattern">
            <img src="assets/images/shape-pattern.png" alt="">
        </div>
    </section> -->
    
    <!--====== NEWS PART ENDS ======-->


    <!--====== COMPANY LOGOS PART START ======-->
    
    <!-- <section class="company-logos-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="company-logos-text">
                        <h3 class="title">Clients we <br> have worked <br> with.</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section> -->
    
    <!--====== COMPANY LOGOS PART ENDS ======-->

<!-- Footer section start -->
<?php include 'include/footer.php'; ?>
