<!-- Header section start -->
<?php include 'include/header.php'; ?>

    <!--====== PAGE TITLE PART START ======-->

    <div class="page-title-area bg_cover" style="background-image: url(assets/images/page-title-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title-content">
                        <h3 class="title">Book a tour</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Book a tour</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--====== PAGE TITLE PART ENDS ======-->

    <!--====== WRITE MASSAGE PART START ======-->
    
    <section class="write-massage-area pb-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                    <div class="write-massage-content">
                        <div class="write-massage-title">
                            <h3 class="title">We'll follow up</h3>
                        </div>
                        <div class="write-massage-input">
                            <form action="#">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Phone">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="I’m interested in">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Company size">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Date">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Time">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input-box mt-10">
                                            <textarea name="#" id="#" cols="30" rows="10" placeholder="Message"></textarea>
                                            <button class="main-btn main-btn-2">Send message</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="book-a-tour-info">
                        <span>Need quick help?</span>
                        <p>Speak with a human to filling out a form? call corporate office and we will connect you with a team member who can help.</p>
                        <h3 class="title">+91 88843 32801</h3>
                        <!-- <li><a href="tel:88843 32801"></a></li> -->
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== WRITE MASSAGE PART ENDS ======-->

    <!--====== COMPANY LOGOS PART START ======-->
    
    <!-- <section class="company-logos-area">
        <div class="container">
            <div class="row">
                <div class="col-lg-5">
                    <div class="company-logos-text">
                        <h3 class="title">Clients we <br> have worked <br> with.</h3>
                    </div>
                </div>
                <div class="col-lg-7">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-15">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="logo-item mt-80">
                                <img src="assets/images/brand-1.png" alt="">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
     -->
    <!--====== COMPANY LOGOS PART ENDS ======-->

  
<!-- Footer section start -->
<?php include 'include/footer.php'; ?>