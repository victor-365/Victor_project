<!-- Header section start -->
<?php include 'include/header.php'; ?>

    <!--====== PAGE TITLE PART START ======-->

    <div class="page-title-area bg_cover" style="background-image: url(assets/images/page-title-bg.jpg);">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="page-title-content">
                        <h3 class="title">Contact</h3>
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="index.php">Home</a></li>
                                <li class="breadcrumb-item active" aria-current="page">Contact</li>
                            </ol>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <!--====== PAGE TITLE PART ENDS ======-->

    <!--====== CONTACT INFO PART START ======-->
    
    <section class="contact-info-area">
        <div class="container">
            <div class="contact-info">
                <div class="row">
                    <div class="col-lg-4">
                        <div class="contact-info-content">
                            <h3 class="title">Feel free to get in touch with Moms Co-Work.</h3>
                            <ul>
                                <li><img src="assets/images/icon/icon-1.png" alt=""> Hoysala nagar Horamavu 3rd Main, 6th Cross Rd, Bengaluru, Karnataka 560016</li>
                                <li><img src="assets/images/icon/icon-2.png" alt=""> richa.oneapps@gmail.com</li>
                                <li><img src="assets/images/icon/icon-3.png" alt=""> +91 88843 32801</li>
                                <li><img src="assets/images/icon/icon-4.png" alt=""> 24 hours / 7 days a week</li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="contact-info-thumb">
                            <img src="assets/images/contact-info-thumb.jpg" alt="">
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="contact-info-text">
                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some injected humour, or randomised words.</p>
                            <p class="text">Which don't look even slightly believable. If you are going to use a passage of you need to be sure there embarrassing.</p>
                            <img src="assets/images/singin.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== CONTACT INFO PART ENDS ======-->
            
    <!--====== WRITE MASSAGE PART START ======-->
    
    <section class="write-massage-area pb-120">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-8">
                    <div class="write-massage-content">
                        <div class="write-massage-title text-center">
                            <h3 class="title">Write us message.</h3>
                        </div>
                        <div class="write-massage-input">
                            <form action="#">
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Phone">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="input-box mt-10">
                                            <input type="text" placeholder="Subject">
                                        </div>
                                    </div>
                                    <div class="col-lg-12">
                                        <div class="input-box mt-10 text-center">
                                            <textarea name="#" id="#" cols="30" rows="10" placeholder="Message"></textarea>
                                            <button class="main-btn main-btn-2">Send message</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    <!--====== WRITE MASSAGE PART ENDS ======-->        

    <!-- map section start -->
    <div class="map-area">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3887.2955008927765!2d77.66288757473531!3d13.01684478730269!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae10d81bfa2bab%3A0x1d66b6b96a7269e5!2s3rd%20Main%20Rd%20%26%206th%20Cross%20Rd%2C%20Hoysala%20Nagar%2C%20Ramamurthy%20Nagar%2C%20Bengaluru%2C%20Karnataka%20560016!5e0!3m2!1sen!2sin!4v1686986618900!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <!-- map section end -->

   
   
    <!-- Footer section start -->
    <?php include 'include/footer.php'; ?>
        
   